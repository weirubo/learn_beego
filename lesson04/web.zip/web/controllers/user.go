package controllers

import (
	"fmt"
	"github.com/astaxie/beego/server/web"
	"log"
)

type UserController struct {
	web.Controller
}

func (u *UserController) Create() {
	// u.Ctx.WriteString("UserController@Create")
	// 请求数据
	uid, err := u.GetInt64("uid")
	if err != nil {
		log.Fatalln(err.Error())
		return
	}
	fmt.Println(uid)
	// 输出数据
	// u.Ctx.WriteString(strconv.FormatInt(uid, 10))
}

